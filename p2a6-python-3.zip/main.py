#Constanza Gonzalez Vazquez Ingenieria De Animacion 00606435

import pandas as pd
formula1 = { "edades": [37, 19, 35, 33, 27, 27, 29, 32, 30, 20], } 
df = pd.DataFrame(formula1)
print("Formula 1 del campeonato de 2025 ")
print(df)

print(df.mean())

edades = [37, 19, 35, 33, 27, 27, 29, 32, 30, 20]
cuantos= 0 
for x in edades: 
    if  x >= 30: 
        cuantos += 1
porcentaje =  cuantos / len(edades) * 100 
print(porcentaje,"%")
print("El numero de pilotos cuya se encuentra debajo de promedio de la muestra: " , len(edades) - cuantos )