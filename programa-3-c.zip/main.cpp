//Constanza Gonzalez Vazquez Ingieria de Animacion Digital 00606435
#include <iostream>
using namespace std;
int main()
{
        
    int secreto = 12345;
    int code;

  
    cout <<"Ingrese codigo" << endl;
    cin >> code;
while (code != secreto) {
    cout << "Codigo incorrecto" << endl;
    cin >> code;
}//Finmientras
cout << "Acceso permitido" << endl;

    return 0;
}