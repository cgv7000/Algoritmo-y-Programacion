#Constanza Gonzalez Vazquez Ingieneria de Animacion Digital 00606435
#Programa 2
  
amigos = int(input("¿Cuantos amigos se juntaron para comer?"))
costo = float(input("¿Cuanto costo la pizza?"))
  
print("Al se " , amigos, "pargara cada uno:" , round(costo/amigos,2))