#Constanza Gonzalez Vazquez Ingieneria de Animacion Digital 00606435
A = 1

while A < 11:
  print(A)
  A+=1 # A = A+1
  
print ("Termine de contar")