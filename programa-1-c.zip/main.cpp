//Programa 1
//Constanza Gonzalez Vazquez Ingieneria de Animacion Digital 00606435

#include <iostream>
using namespace std;
int main( )

{
  int amigos;
  double costo;
   cout<< "¿Cuantos amigos se juntaron para comer?"<<endl;
   cin>> amigos;
   cout << "¿Cuanto costo la pizza"<<endl;
   cin >> costo;
   cout << " Al ser " << amigos <<" pagara canda uno " << costo/amigos << endl;

    return 0;
}