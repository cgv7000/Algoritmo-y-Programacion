//*Constanza Gonzalez Vazquez Ingieneria De Animacion Digital 00606435
//#Programa 8
#include <iostream>
using namespace std;
int main()
{
   for(int a = 1; a<=10; a++){
       cout<< a << endl;
   }

    return 0;
}