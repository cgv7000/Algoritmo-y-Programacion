#Constanza Gonzalez Vazquez Ingenieria de animacion dital 00606435
#Aleatorio 4
#Elegir desde una lista

import random

numeros = [ 10, 100, 1000, 10000, 100000, 1000000]
valor = random.choice(numeros)
print("Elegir un numero de la lista: ", valor)

materias = [ "programacion", "matematicas" , "algebra", "dibujo", "color", " ser "]
valor = random.choice(materias)
print("La materia que rebrobare es ", valor)
 
valor = random.choice([3, "hola",4.5,"feliz",1000])
print("Otros valores ", valor)
 
print(random.choice(["hp5", "salud 2"," central", "edificio 5"]))