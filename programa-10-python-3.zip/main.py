
#Constanza Gonzalez Vazquez Ingenieria Animacion Digital 00606435
#Program 10 Python 3

for a in range(0,101,2):
    print(a, end = ",")