#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 0606435
#Programa 2 - Modificar los valores de una lista

cal = [0,0,0,0,0,]# Lista con 5 elementos
print(cal)
cal[0] = 9
cal[1] = 7
cal[2] = 8
cal[3] = 10
cal[4] = 6
print(cal)
 
nombres = ["",""]
print(nombres)
nombres[0] = input("Ingresa un nombre: ")
nombres[1] = input("Ingresa un nombre: ")
print(nombres)