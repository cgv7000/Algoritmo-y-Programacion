//Constanza Gonzalez Vazquez Ingeniera De Animacion DIgital 00606435
//Programa 11 C++

#include <iostream>
using namespace std;
int main()
{

  for (int a = 10; a>=1; a--){
    cout << a << endl;
}

    return 0;
}