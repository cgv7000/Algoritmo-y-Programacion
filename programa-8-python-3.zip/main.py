#Constanza Gonzalez Vazquez Ingenieria De Animacion Digital 00606435
#Programa 8 Python 3 

for a in range(1,10):
    print(a)
    