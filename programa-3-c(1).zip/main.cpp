//Constanza Gonzalez Vazquez Ingeneria De Animacion Digital 00660435
//Programa 3 - Solicitar 5 calififcacion por teclado y 
// almacenar en un arreglo y mostrarles en pantalla
//utilizando un para separarlas.

#include <iostream>
using namespace std;

int main()
{
     int calificacion [5];
     //calificacion [8] = 8;
     cout << "Ingresa el valor 1: ";
     cin >> calificacion [0];
     cout << "Ingresa el valor 2: ";
     cin >> calificacion [1];
     cout << "Ingresa el valor 3: ";
     cin >> calificacion [2];
     cout << "Ingresa el valor 4: ";
     cin >> calificacion [3];
     cout << "Ingresa el valor 5: ";
     cin >> calificacion [4];
     for (int i=0; i<5; i++){
         cout << calificacion [i] << "-";
     }
     
     
    
    return 0;
}