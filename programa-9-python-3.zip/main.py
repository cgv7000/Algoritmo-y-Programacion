#Constanza Gonzalez Vazquez Ingenieria De Animacion Digital 00606435
#Pragrama 9 python 

for a in range(1,11,2):
    print(a)