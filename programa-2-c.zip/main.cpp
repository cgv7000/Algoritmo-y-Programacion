//Constanza Gonzalez Vazquez Ingeneria De Animacion Digital 00660435
//Programa 2
#include <iostream>
using namespace std;
int main()
{
    
    
    int calificacion[9]= {8,7,10,8,5,6,9,10,8};
    
    
    //Mostrar valores en pantalla
    for(int indice = 0; indice <= 8; indice++)
    
  { 
      cout << calificacion[indice] << endl;
  }

    return 0;
}