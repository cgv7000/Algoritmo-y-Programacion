//*Constanza Gonzalez Vazquez Ingenieria De Animacion Digital 0606435
//*Programa 9 
#include <iostream>
using namespace std;
int main()
{
   for (int a=1; a<=10; a+=2){
        cout << a << endl; 
   }

    return 0;
}