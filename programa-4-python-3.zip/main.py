#Constanza Gonzalez Vazquez Ingenria de Animacion 00606435
#Programa 4
secreto = 123456;
code = int(input("Ingrese  codigo"))
 
while code != secreto:
     print("Codigo incorrecto")
     code = int(input())
     
     
print ("Acceso permitido")