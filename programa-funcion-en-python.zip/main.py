#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 00606435
#Funcion EN PYTHON
#No hay tipo de Datos, pero si existen parametros
#Para crear una funcion en Pyhton se utiliza la palabra
# >> DEF <<
#Es posible un return
#La funciones se defienden antes de llamarlas



#fUNCIONES SENCILLA -> Sin return, sin parametros
def primeraFuncion():
    print("Mi primera funcion en Python")
    print("Funcion sencilla")

#Funcion que recibe un parametro
def segundaFuncion(valor):
    print("El valor actual es: " , valor)
    
def terceraFuncion(valor):
    print("El valor", valor, "elevado al cuadrado es: ", pow(valor, 3))

#Funcion sin parametros que retorne un valor 
def cuartaFuncion():
    return "Hoy es una dia genial" #retorno de cadena de texto
    
def quintaFuncion():
    valor = 23
    return valor
    
def sextaFuncion():
    return True
    
#Funciones que retornan valor y reciben 1, 2 o mas parametros

def septimaFuncion(valor):
    return valor*3

def octavaFuncion(valor1, valor2):
    return pow(valor1, valor2)
    
    
    
#Llamar o invocar una Funcion 
primeraFuncion()

segundaFuncion("Programacion")
segundaFuncion(45)

terceraFuncion(8)

print(cuartaFuncion())
x = cuartaFuncion()
print("Utilizando x: " , x)

print(quintaFuncion())
x = quintaFuncion()
print("Utilizando x: " , x)

print(sextaFuncion())
x = sextaFuncion()
print("El valor de x es: ", x)

print(septimaFuncion(8))
x = septimaFuncion("Hola")
print(x)

print(octavaFuncion(2,3))
x = octavaFuncion (10,5)
print(x)

    
