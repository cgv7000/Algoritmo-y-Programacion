#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 00606435

datos = [10 , 45 , 20 , 35, 50, 60,  8,  99, 67, 77]
print(datos)

suma = 0 
for x in range(10):
 suma += datos[x]
print(suma)

datosinversos = []
for y in reversed(datos):
 datosinversos.append(y)  
print(datosinversos)

index = 0
datosvalor = datos[0]
for c in range(10):
 if datosvalor < datos[c]:
     datosvalor = datos[c]
     index = c 
print(datosvalor)
print("El indice del valor mas grande es: " , index)








