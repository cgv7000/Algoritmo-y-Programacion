#Constanza Gonzalez Vazquez Inenieria De Animacion Digital 00606436
#Programa 5  - Segmento/Rocorte/Rebanar

t = ['a', 'b', 'c', 'd', 'e', 'f']
#Obtener [b,c]
print(t[1:3])
print(t[3:5])

#Obtener los primeros cuatros elementos

print(t[0:4])
print(t[:4])

#Obtener los ultimos 3 elementos
print(t[3:6])
print (t[:3])
print(t[len(t)-3:]) #equivale a <6-3>

print(t[:])
