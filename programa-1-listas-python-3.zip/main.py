#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 0606435
#Programa 1 - Declaracion e impresion de listas 

nombres =  ["Ana","Ruben","Sonia","Jose"]
print(nombres)#Imprime todos los elemntos de la lista


print(nombres[2])#Imprirmir solo el valor"Sonia"
 
#Listas con valores mixtos
fecha = ["jueves",9,"Octubre",2025]
print(fecha)
print(fecha[0]," ",fecha[1], "/", fecha[2], "/", fecha[3])

lista1 = ["Dracula", 2014]
lista2 = ["Dracula", 2022]
cine = [lista1,lista2]
print(cine)

disney = [["Toy Story",1985], ["Una nueva esperanza", 1972]]
print(disney)
print(disney [0][0])
print(disney [1][0])
