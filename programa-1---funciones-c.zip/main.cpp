//Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 00606435
//Programa 1 - funciones
//Las funciones son bloques de codigos que permiten una mejor lectura
//y manipulacio de los programas, entre mas segmentos este un codigo 
//mas sencillo en su mantenimiento
 
#include <iostream>
using namespace std;

//Funcion sin tipo de dato (tipo generico) , sin peremetros
void primeraFuncion(){
    cout << "Mi primera funcion" << endl;
    
}
//Funcion sin tipo de Dato, con un parametros
void segundaFuncion(int a){
    int r;
    r = a* 2 / 100;
    cout << "ahora el valor de a es : " << r << endl;

}

//Funcion con tipo de Dato, Sin parametros 
string terceraFuncion(){
    return "Estoy retornando una cadena de caracteres"; 
}

    


//Funcion sin tipo de Dato, Con parametro
int cuartaFuncion(int a){
    return a*a;
}

double quintaFuncion(double a, int b){
    return b/a * 10;
}
 
int main()

{
    
  //Llamado o invocacion de funciones
  primeraFuncion();
  
  //Llamando de la segunda Funciones 
  //1ra opcion - pasar el valor de forma directa
  segundaFuncion(8);
  //2da opcion - asignar el valor a una variable del mismo tipo
  int valor = 10000;
  segundaFuncion(valor); 
  //3rd opcion - solicitar un valor usuario 
  cout << "Ingresa un valor: "; cin >> valor;
  segundaFuncion(valor);
  
  
  //Llamado a la terceraFuncion 
  //1rea opcion - imprimir el valor de forma directa
  cout << terceraFuncion() << endl;
  //2da opcion - asignar el valor de retorno a una variable 
  string cadena; 
  cadena = terceraFuncion(); 
  cout << cadena << endl;
  
  //Llamado a la cuartaFuncion 
  cout << cuartaFuncion(8) << endl;
  
  int r = cuartaFuncion(12);
  cout << r << endl;
  cout << "Ingresa un valor para la funcion 4: "; cin >> r; 
  cout << cuartaFuncion(r) << endl; 
  
  //Llamando la quintaFuncion 
  cout << quintaFuncion(2.5, 6 ) << endl; 
  
  double v = quintaFuncion(1.0,1);
  cout << v << endl;
  
  double x; int y; 
  cout << " Ingresa el valor 1 para la funcion 5: "; cin >> x; 
  cout << " Ingresa el valor 2 para la funcion 5: "; cin >> y; 
  cout << quintaFuncion(x, y) << endl; 
 
  
  
  return 0;
}