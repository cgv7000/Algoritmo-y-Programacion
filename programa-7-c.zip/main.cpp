//Constanza Gonzalez Vazquez Ingenieria De Animacion Digital 00606435
//Programa 7
#include <iostream>
using namespace std;
int main()
{
  int secreto = 123456;
  int code;
  
  do{ //Repetir 
     cout << "Ingresa el codigo: " << endl;
     cin >> code;
     
 } while ( code !=secreto);// mientras(la condicion sea verdadera)
   
   cout << "Acceso permitido. " << endl;

  return 0;
}