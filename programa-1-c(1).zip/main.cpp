//Constanza Gonzalez Vazquez Ingeneria De Animacion Digital 00660435
//Programa 1
#include <iostream>
using namespace std;
int main()
{
   //Representar la calificaciones del semestre
   //int Cal1, Cal2, Cal3, Cal4, Cal5, Cal6, Cal7, Cal8, Cal9,;
   //AREGGLOS (ARRAYS)
   //Conjunto de elementos del mismo tip de datos, con tamano fijo y
  //un indice que controla la posicion de los elementos del arreglo.
  
  int calificacion [9];
  
  calificacion [0] = 8;
  calificacion [1] = 7;
  calificacion [2] = 10;
  calificacion [3] = 8;
  calificacion [4] = 5;
  calificacion [5] = 6;
  calificacion [6] = 9;
  calificacion [7] = 10;
  calificacion  [8] = 8;
  
 cout << calificacion [0] << endl;
 cout << calificacion [1] << endl;
 cout << calificacion [2] << endl;
 cout << calificacion [3] << endl;
 cout << calificacion [4] << endl;
 cout << calificacion [5] << endl;
 cout << calificacion [6] << endl;
 cout << calificacion [7] << endl;
 cout << calificacion [8] << endl;
  
  
     
    return 0;
}