#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 0606435
#Programa 3 - Reccorido de listas

quesos = ["gouda", "cheddar", "quesilloa", "crema","bola","sopero"]
print(quesos)

#Alternativa 1 - for clasico
print("\nAlternativa 1 - for clasico")
for i in range(6):
    print(quesos[i], end=",")
    

#Alternativa 2 - for clasico, sin conocer el tamano de la lista
print("\n\nAlternativa 2  - for clasico sin conocer el tamano de la listas")
for i in range(len(quesos)):
    print(quesos[i], end=",")
    
#Alternativa 3 - for con listas
print("\n\nAlternativa 3 - for con listas")
for quesos in quesos:
    print(quesos, end= ",")


