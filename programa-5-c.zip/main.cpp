//Constanza Gonzalez Vazquez Ingieneria de Animacion Digital 00606435
#include <iostream>
using namespace std;
int main()
{
   int A = 1;
   
   while (A<11){
       cout << A<< endl;
       A++; // A=A+1
   }
   cout << "Termine de contar" << endl;

    return 0;
}