#Constanza Gonzalez Vazquez Ingenieria De Animacion 00606435
#Programa 11 Python 3
for a in range(10,0,-1):
    print (a)

