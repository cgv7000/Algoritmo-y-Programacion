//Constanza Gonzalez Vazquez Ingeneria De Animacion Digital 00660435
//Programa 5
#include <iostream>
using namespace std;
int main()
{
    int calificacion[5];
    int suma;
    int promedio;
    
    for (int i=0; i<5; i++){
        cout << "Ingresa el valor " << ( i+1) << ": ";
        cin >> calificacion [i];
        suma = suma + calificacion [i];
    }
    promedio = suma/5;
    cout << "La suma de las calificacion es: " << suma << endl;
    cout << "El promedion de las calificaciones es: " << promedio << endl;
    return 0;
}