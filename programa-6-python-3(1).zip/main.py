#Constanza Gonzalez Vazquez Inenieria De Animacion Digital 00606436
#Programa 6 - agregar y elminar

peliculas = ["Dune", "Avatar 3", "Guardian of the Galaxy 4"]

#En python las listas son flexibles
#pueden agregar elementos tantos como se necesiten

peliculas.append("Indiana Jones 6")
print(peliculas)

peliculas.append("Fast and Ferious 11")
print(peliculas)

#Eliminar elementos
#Caso 1. Utilizando el metodo pop()
print("Eliminamos el ultimo elemento de la historia")
peliculas.pop()
print(peliculas)

print("\nEliminar la pelicula Avatar 3")
peliculas.pop(1)
print(peliculas)

#Caso 2. Utlilizandoel metodo del 
print("\nEliminamos el ultimos elemento de la lista")
del peliculas[len(peliculas)-1]
print(peliculas)

print("\nEliminar la pelicula Dune")
del peliculas[0]
print(peliculas)


