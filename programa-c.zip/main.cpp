//Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 00606435
#include <iostream>
using namespace std;

int formula1[10] = {37, 19, 35, 33, 27, 27, 29, 32, 30, 20};


int main()
{
    cout << "Formula 1 del campeonato 2025" << endl;
    cout << "edades" << endl;
    
    int total = 0;
    int promedio = 0;
    int cuantos = 0;
    for(int i = 0; i < 10 ; i++){
        cout << formula1[i] << endl;
        
        total = total + formula1[i];
        
        if(formula1[i] >= 30){
            cuantos = cuantos + 1;
        }
    }
    
    promedio = total / 10;
    float porcentaje = cuantos / 10.0 * 100;
    cout << "promedio de edad: " << promedio << endl;
    cout << "porcentaje de pilotos con major de 30 años: " << porcentaje <<"%" << endl;
    cout << "Pilotos cuya edad se encuentra por debajo del promedio de la muestra: " << 10 - cuantos;
    
    }