//Constanza Gonzalez Vazquez Ingenieria de Animacion 00606435
//ALEATORIO 1 
//General numero pseudaleatorios.
//Utilizando una semilla, es la fecha y hora actual del sistema
#include <iostream>
#include <cstdlib> //liberia que contiene funciones aleatorios
using namespace std;
int main()
{
 srand(time(NULL));  //Genera de semilla  
 int n; //almacena el numero aleatorio generado   
 n = rand();//La fincion rand genera un numero aleatorio
 cout << n; 
    
 return 0;
    
}