//Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 00606435
//Aleatorio 2
#include <iostream>
#include <cstdlib>
using namespace std;
int main()
{
   srand(time(NULL));
   int n;

  //Genrar valores entre 0 y 99
    n = rand()% 100;
    cout << "valores entre 0 y 99: " << n << endl;
    
    //Generar valores entre  1 Y 100
    n = rand() % 101 + 1;
    cout << "Valores aleatorios entre 1 y 100: " << n << endl;
    
    //Generar valores entre 5 y 10
    n = rand() % 6 + 5; 
    cout << "Valores aleatorio entre 5 y 10: " << n << endl;
  
    
    n = rand()% 11 + 20;
    cout << "Valores aleatorio entre 20 y 30: " << n << endl;
    return 0;
}
