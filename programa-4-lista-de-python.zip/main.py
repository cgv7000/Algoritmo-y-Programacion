#Constanza Gonzalez Vazquez Ingenieria de Animacion Digital 0606435
#Programa 4 - Operaciones de listas 

#Concatencion de listas (union)
a = [1,2,3]
b = [4,5,6,]
c = a + b 
print(c)

nombres = ["Juan", " Maria", "Pedro"]
cuidad = [ "Merida", "CDMX", "Oaxaca"]
datos = nombres + cuidad 
print(datos)

#Repeticion (*)
print ()
print (a*3)
print(["I","love", "python"]*2)
