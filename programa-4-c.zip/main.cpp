//Constanza Gonzalez Vazquez Ingeneria De Animacion Digital 00660435
#include <iostream>
using namespace std;
int main()
{
   int calificacion [5];
    
  for(int i=0; i<5; i++) {
      cout << "Ingrasa el valor " << (i+1) << ": ";
      cin >> calificacion [i];
  }
  
  for (int i=0; i<5; i++) {
      cout << calificacion [1] << "-";
  }

    return 0;
}